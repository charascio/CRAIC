#include "libHelloSLAM.h"

int main(int argc, char *argv[])
{
    printHello();
    return 0;
}
