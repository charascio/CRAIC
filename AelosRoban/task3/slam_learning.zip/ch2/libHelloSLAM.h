#ifndef LIBHELLOSLAM_H_
#define LIBHELLOSLAM_H_

void printHello();

#endif