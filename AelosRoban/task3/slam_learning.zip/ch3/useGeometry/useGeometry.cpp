#include <iostream>
#include <cmath>
using namespace std;

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>
using namespace Eigen;

int main(int argc, char *argv[])
{
    Matrix3d rotation_matrix = Matrix3d::Identity();
    AngleAxisd rotation_vector(M_PI / 4, Vector3d(0, 0, 1));
    cout.precision(3);
    cout << "rotation matrix = " << endl << rotation_vector.matrix() << endl;

    rotation_matrix = rotation_vector.toRotationMatrix();

    Vector3d v(1, 0, 0);
    Vector3d v_rotated = rotation_vector * v;
    cout << "after rotate vector: " << v_rotated.transpose() << endl;
    v_rotated = rotation_matrix * v;
    cout << "after rotate matrix: " << v_rotated.transpose() << endl;

    Vector3d euler_angles = rotation_matrix.eulerAngles(2, 1, 0); //Z X Y
    cout << "yaw pitch roll" << euler_angles.transpose() << endl;

    Isometry3d T = Isometry3d::Identity();
    T.rotate(rotation_vector);
    T.pretranslate(Vector3d(1, 3, 4));
    cout << "Transform Matrix: " << endl << T.matrix() << endl;

    Vector3d v_transformed = T * v;
    cout << "transformed: " << v_transformed.transpose() << endl;

    Quaterniond q = Quaterniond(rotation_vector); //(x, y, z, w)
    cout << "quaterniond1" << q.coeffs().transpose() << endl;
    q = Quaterniond(rotation_matrix);
    cout << "quaterniond2" << q.coeffs().transpose() << endl;

    v_rotated = q * v;
    cout << "rotated" << v_rotated.transpose() << endl;
    
    return 0;
}
