#include <iostream>
using namespace std;

void printHello()
{
    cout << "Hello SLAM!" << endl;
}